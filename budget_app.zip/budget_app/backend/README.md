Backend: simple NestJS skeleton. Run `npm install` and `npm run start:dev`.
